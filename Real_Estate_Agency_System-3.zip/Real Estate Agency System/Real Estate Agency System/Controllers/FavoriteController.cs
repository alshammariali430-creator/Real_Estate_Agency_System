using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using RealEstateAgency.Models;

namespace RealEstateAgency.Controllers
{
    [Authorize] // requires login
    public class FavoriteController : Controller
    {
        private readonly AppDbContext ctx;
        private readonly UserManager<ApplicationUser> userManager;

        public FavoriteController(AppDbContext ctx, UserManager<ApplicationUser> userManager)
        {
            this.ctx = ctx;
            this.userManager = userManager;
        }

        // List the current user's favorites
        public IActionResult Index()
        {
            string userId = userManager.GetUserId(User) ?? "";

            // Get all favorite records for this user
            var favorites = ctx.Favorites.Where(f => f.AppUserID == userId).ToList();

            // Get the property for each favorite
            var properties = new List<Property>();
            foreach (var fav in favorites)
            {
                var p = ctx.Properties.FirstOrDefault(x => x.PropertyID == fav.PropertyID);
                if (p != null)
                {
                    properties.Add(p);
                }
            }
            return View(properties);
        }

        // Add a property to favorites
        public IActionResult AddFavorite(int id)
        {
            string userId = userManager.GetUserId(User) ?? "";

            var property = ctx.Properties.Find(id);
            if (property == null)
            {
                return NotFound();
            }

            // Check if already in favorites
            var existing = ctx.Favorites.FirstOrDefault(f => f.AppUserID == userId && f.PropertyID == id);
            if (existing == null)
            {
                var fav = new Favorite();
                fav.AppUserID = userId;
                fav.PropertyID = id;
                fav.DateAdded = DateTime.Now;
                ctx.Favorites.Add(fav);
                ctx.SaveChanges();
            }

            return RedirectToAction("Details", "Property", new { id = id });
        }

        // Remove a property from favorites
        public IActionResult RemoveFavorite(int id)
        {
            string userId = userManager.GetUserId(User) ?? "";
            var fav = ctx.Favorites.FirstOrDefault(f => f.AppUserID == userId && f.PropertyID == id);
            if (fav != null)
            {
                ctx.Favorites.Remove(fav);
                ctx.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
