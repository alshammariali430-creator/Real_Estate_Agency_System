using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RealEstateAgency.Models;

namespace RealEstateAgency.Controllers
{
    public class PropertyController : Controller
    {
        // dependency injection - access the database
        private readonly AppDbContext ctx;

        public PropertyController(AppDbContext ctx)
        {
            this.ctx = ctx;
        }

        // ============================================================
        // PUBLIC BROWSING - anyone can see these
        // ============================================================

        // Browse all properties
        public IActionResult Index()
        {
            var properties = ctx.Properties.Where(p => p.Status == "Available")
                                            .OrderByDescending(p => p.DateListed)
                                            .ToList();
            return View(properties);
        }

        // SEARCH FUNCTION 1: Search by location (querystring)
        public IActionResult SearchByLocation(string? location)
        {
            // Read all available properties first
            var results = ctx.Properties.Where(p => p.Status == "Available").ToList();

            if (!string.IsNullOrEmpty(location))
            {
                results = results.Where(p => p.Location.Contains(location)).ToList();
            }

            ViewBag.Location = location;
            return View(results);
        }

        // SEARCH FUNCTION 2: Search by price range (querystring)
        public IActionResult SearchByPrice(int? minPrice, int? maxPrice)
        {
            var results = ctx.Properties.Where(p => p.Status == "Available").ToList();

            if (minPrice.HasValue)
            {
                results = results.Where(p => p.Price >= minPrice.Value).ToList();
            }

            if (maxPrice.HasValue)
            {
                results = results.Where(p => p.Price <= maxPrice.Value).ToList();
            }

            ViewBag.MinPrice = minPrice;
            ViewBag.MaxPrice = maxPrice;
            return View(results);
        }

        // SEARCH FUNCTION 3: Search by type (querystring)
        public IActionResult SearchByType(string? type)
        {
            var results = ctx.Properties.Where(p => p.Status == "Available").ToList();

            if (!string.IsNullOrEmpty(type))
            {
                results = results.Where(p => p.Type == type).ToList();
            }

            ViewBag.Type = type;
            return View(results);
        }

        // View property details + track in session
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var property = ctx.Properties.FirstOrDefault(p => p.PropertyID == id);

            if (property == null)
            {
                return NotFound();
            }

            // SERVER-BASED STATE MANAGEMENT - track recently viewed in session
            // Stored as a comma-separated list of IDs (Lab 06a session pattern)
            string recentList = HttpContext.Session.GetString("RecentlyViewed") ?? "";

            // Build a new list with this id at the front
            List<string> ids = recentList.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();
            ids.Remove(id.ToString()!);
            ids.Insert(0, id.ToString()!);

            // Keep only the last 5
            if (ids.Count > 5)
            {
                ids = ids.Take(5).ToList();
            }

            HttpContext.Session.SetString("RecentlyViewed", string.Join(",", ids));

            return View(property);
        }

        // Recently viewed properties from session
        public IActionResult RecentlyViewed()
        {
            string recentList = HttpContext.Session.GetString("RecentlyViewed") ?? "";
            var properties = new List<Property>();

            if (!string.IsNullOrEmpty(recentList))
            {
                string[] idStrings = recentList.Split(',');
                foreach (string idString in idStrings)
                {
                    if (int.TryParse(idString, out int id))
                    {
                        var p = ctx.Properties.FirstOrDefault(x => x.PropertyID == id);
                        if (p != null)
                        {
                            properties.Add(p);
                        }
                    }
                }
            }

            return View(properties);
        }

        // Clear the recently viewed session list
        public IActionResult ClearRecentlyViewed()
        {
            HttpContext.Session.Remove("RecentlyViewed");
            return RedirectToAction("RecentlyViewed");
        }

        // ============================================================
        // ADMIN CRUD - only for admin role
        // ============================================================

        // Admin dashboard - manage properties
        [Authorize(Roles = "Admin")]
        public IActionResult Manage()
        {
            var properties = ctx.Properties.OrderByDescending(p => p.DateListed).ToList();
            return View(properties);
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult AddProperty()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult AddProperty(Property property)
        {
            if (ModelState.IsValid)
            {
                property.DateListed = DateTime.Now;
                ctx.Properties.Add(property);
                ctx.SaveChanges();
                return RedirectToAction("Manage");
            }
            return View(property);
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult UpdateProperty(int id)
        {
            var property = ctx.Properties.Find(id);
            if (property == null)
            {
                return NotFound();
            }
            return View(property);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult UpdateProperty(Property property)
        {
            if (ModelState.IsValid)
            {
                ctx.Properties.Update(property);
                ctx.SaveChanges();
                return RedirectToAction("Manage");
            }
            return View(property);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult DeleteProperty(int id)
        {
            var property = ctx.Properties.Find(id);
            if (property != null)
            {
                ctx.Properties.Remove(property);
                ctx.SaveChanges();
            }
            return RedirectToAction("Manage");
        }
    }
}
