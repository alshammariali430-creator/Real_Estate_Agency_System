using Microsoft.AspNetCore.Mvc;
using RealEstateAgency.Models;

namespace RealEstateAgency.Controllers
{
    public class HomeController : Controller
    {
        // dependency injection - access the database
        private readonly AppDbContext ctx;

        public HomeController(AppDbContext ctx)
        {
            this.ctx = ctx;
        }

        public IActionResult Index()
        {
            // Get featured properties (top 3 most recent)
            var featured = ctx.Properties.Where(p => p.Status == "Available")
                                          .OrderByDescending(p => p.DateListed)
                                          .Take(3)
                                          .ToList();
            return View(featured);
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        // Custom error page for unhandled exceptions
        public IActionResult Error()
        {
            var model = new ErrorViewModel();
            model.Message = "An unexpected error occurred. Please try again later.";
            return View(model);
        }

        // Custom HTTP status code page (404, 403, 500, etc.)
        public IActionResult StatusCode(int? code)
        {
            string message;
            if (code == 404)
                message = "The page you are looking for could not be found.";
            else if (code == 403)
                message = "You do not have permission to access this resource.";
            else if (code == 500)
                message = "Something went wrong on our server.";
            else
                message = "An error occurred while processing your request.";

            var model = new ErrorViewModel();
            model.StatusCode = code;
            model.Message = message;
            return View(model);
        }

        // CLIENT-BASED STATE MANAGEMENT - save theme preference as a cookie
        // Lab 05b cookie pattern
        [HttpPost]
        public IActionResult SetTheme(string theme)
        {
            CookieOptions options = new CookieOptions();
            options.Expires = DateTime.Now.AddDays(30);
            Response.Cookies.Append("Theme", theme, options);
            return Redirect(Request.Headers["Referer"].ToString());
        }
    }
}
