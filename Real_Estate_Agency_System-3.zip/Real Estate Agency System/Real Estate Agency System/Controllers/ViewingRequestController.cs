using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using RealEstateAgency.Models;

namespace RealEstateAgency.Controllers
{
    [Authorize]
    public class ViewingRequestController : Controller
    {
        private readonly AppDbContext ctx;
        private readonly UserManager<ApplicationUser> userManager;

        public ViewingRequestController(AppDbContext ctx, UserManager<ApplicationUser> userManager)
        {
            this.ctx = ctx;
            this.userManager = userManager;
        }

        // List the user's viewing requests (or all if admin)
        public IActionResult Index()
        {
            string userId = userManager.GetUserId(User) ?? "";

            List<ViewingRequest> requests;
            if (User.IsInRole("Admin"))
            {
                requests = ctx.ViewingRequests.OrderByDescending(r => r.DateSubmitted).ToList();
            }
            else
            {
                requests = ctx.ViewingRequests.Where(r => r.AppUserID == userId)
                                               .OrderByDescending(r => r.DateSubmitted)
                                               .ToList();
            }

            // Build a property lookup so the view can show titles
            var properties = new Dictionary<int, Property>();
            foreach (var req in requests)
            {
                if (!properties.ContainsKey(req.PropertyID))
                {
                    var p = ctx.Properties.FirstOrDefault(x => x.PropertyID == req.PropertyID);
                    if (p != null)
                    {
                        properties.Add(req.PropertyID, p);
                    }
                }
            }
            ViewBag.Properties = properties;

            return View(requests);
        }

        [HttpGet]
        public IActionResult AddRequest(int id)
        {
            var property = ctx.Properties.Find(id);
            if (property == null)
            {
                return NotFound();
            }

            // Pre-fill form with the property id
            var model = new ViewingRequest();
            model.PropertyID = property.PropertyID;
            model.PreferredDate = DateTime.Now.AddDays(2);

            ViewBag.PropertyTitle = property.Title;
            ViewBag.PropertyLocation = property.Location + ", " + property.City;

            return View(model);
        }

        [HttpPost]
        public IActionResult AddRequest(ViewingRequest req)
        {
            // Server-side validation: date must not be in the past
            if (req.PreferredDate < DateTime.Now.Date)
            {
                ModelState.AddModelError("PreferredDate", "Preferred date cannot be in the past.");
            }

            if (ModelState.IsValid)
            {
                req.AppUserID = userManager.GetUserId(User) ?? "";
                req.DateSubmitted = DateTime.Now;
                req.Status = "Pending";

                ctx.ViewingRequests.Add(req);
                ctx.SaveChanges();
                return RedirectToAction("Index");
            }

            // Re-populate property info if validation fails
            var property = ctx.Properties.Find(req.PropertyID);
            if (property != null)
            {
                ViewBag.PropertyTitle = property.Title;
                ViewBag.PropertyLocation = property.Location + ", " + property.City;
            }
            return View(req);
        }

        // Cancel (delete) a viewing request - JavaScript confirm in the view
        public IActionResult CancelRequest(int id)
        {
            var req = ctx.ViewingRequests.Find(id);
            if (req != null)
            {
                string userId = userManager.GetUserId(User) ?? "";
                // User can only cancel their own request, admin can cancel any
                if (req.AppUserID == userId || User.IsInRole("Admin"))
                {
                    ctx.ViewingRequests.Remove(req);
                    ctx.SaveChanges();
                }
            }
            return RedirectToAction("Index");
        }

        // Admin only - update status
        [Authorize(Roles = "Admin")]
        public IActionResult UpdateStatus(int id, string status)
        {
            var req = ctx.ViewingRequests.Find(id);
            if (req != null)
            {
                req.Status = status;
                ctx.ViewingRequests.Update(req);
                ctx.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
