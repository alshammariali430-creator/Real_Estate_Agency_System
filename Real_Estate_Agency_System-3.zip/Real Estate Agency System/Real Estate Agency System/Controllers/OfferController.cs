using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using RealEstateAgency.Models;

namespace RealEstateAgency.Controllers
{
    [Authorize]
    public class OfferController : Controller
    {
        private readonly AppDbContext ctx;
        private readonly UserManager<ApplicationUser> userManager;

        public OfferController(AppDbContext ctx, UserManager<ApplicationUser> userManager)
        {
            this.ctx = ctx;
            this.userManager = userManager;
        }

        // List user's offers (or all if admin)
        public IActionResult Index()
        {
            string userId = userManager.GetUserId(User) ?? "";

            List<Offer> offers;
            if (User.IsInRole("Admin"))
            {
                offers = ctx.Offers.OrderByDescending(o => o.DateCreated).ToList();
            }
            else
            {
                offers = ctx.Offers.Where(o => o.AppUserID == userId)
                                    .OrderByDescending(o => o.DateCreated)
                                    .ToList();
            }

            // Build a property lookup
            var properties = new Dictionary<int, Property>();
            foreach (var o in offers)
            {
                if (!properties.ContainsKey(o.PropertyID))
                {
                    var p = ctx.Properties.FirstOrDefault(x => x.PropertyID == o.PropertyID);
                    if (p != null)
                    {
                        properties.Add(o.PropertyID, p);
                    }
                }
            }
            ViewBag.Properties = properties;

            return View(offers);
        }

        [HttpGet]
        public IActionResult AddOffer(int id)
        {
            var property = ctx.Properties.Find(id);
            if (property == null)
            {
                return NotFound();
            }

            var model = new Offer();
            model.PropertyID = property.PropertyID;
            model.OfferAmount = property.Price;
            if (property.Listing == "Rent")
            {
                model.OfferType = "Rental Application";
            }
            else
            {
                model.OfferType = "Purchase";
            }

            ViewBag.Property = property;
            return View(model);
        }

        [HttpPost]
        public IActionResult AddOffer(Offer offer)
        {
            if (ModelState.IsValid)
            {
                offer.AppUserID = userManager.GetUserId(User) ?? "";
                offer.DateCreated = DateTime.Now;
                offer.Status = "Pending";

                ctx.Offers.Add(offer);
                ctx.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Property = ctx.Properties.Find(offer.PropertyID);
            return View(offer);
        }

        [HttpGet]
        public IActionResult UpdateOffer(int id)
        {
            var offer = ctx.Offers.Find(id);
            if (offer == null)
            {
                return NotFound();
            }

            string userId = userManager.GetUserId(User) ?? "";
            // User can only edit their own pending offer
            if (offer.AppUserID != userId && !User.IsInRole("Admin"))
            {
                return Forbid();
            }

            if (offer.Status != "Pending")
            {
                return RedirectToAction("Index");
            }

            ViewBag.Property = ctx.Properties.Find(offer.PropertyID);
            return View(offer);
        }

        [HttpPost]
        public IActionResult UpdateOffer(Offer offer)
        {
            if (ModelState.IsValid)
            {
                var existing = ctx.Offers.Find(offer.OfferID);
                if (existing == null)
                {
                    return NotFound();
                }

                string userId = userManager.GetUserId(User) ?? "";
                if (existing.AppUserID != userId && !User.IsInRole("Admin"))
                {
                    return Forbid();
                }

                // Only update editable fields
                existing.OfferAmount = offer.OfferAmount;
                existing.Notes = offer.Notes;

                ctx.Offers.Update(existing);
                ctx.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Property = ctx.Properties.Find(offer.PropertyID);
            return View(offer);
        }

        // Withdraw (delete) an offer - JavaScript confirm in the view
        public IActionResult WithdrawOffer(int id)
        {
            var offer = ctx.Offers.Find(id);
            if (offer != null)
            {
                string userId = userManager.GetUserId(User) ?? "";
                if (offer.AppUserID == userId || User.IsInRole("Admin"))
                {
                    ctx.Offers.Remove(offer);
                    ctx.SaveChanges();
                }
            }
            return RedirectToAction("Index");
        }

        // Admin only - update offer status
        [Authorize(Roles = "Admin")]
        public IActionResult UpdateStatus(int id, string status)
        {
            var offer = ctx.Offers.Find(id);
            if (offer != null)
            {
                offer.Status = status;
                ctx.Offers.Update(offer);
                ctx.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
