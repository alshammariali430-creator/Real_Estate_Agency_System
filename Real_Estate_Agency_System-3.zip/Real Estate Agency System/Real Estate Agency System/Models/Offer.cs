using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RealEstateAgency.Models
{
    public class Offer
    {
        [Key]
        public int OfferID { get; set; }

        [ForeignKey("Property")]
        public int PropertyID { get; set; }
        public Property? Property { get; set; }

        // Set by controller from logged in user
        public string AppUserID { get; set; } = string.Empty;

        [Required(ErrorMessage = "Offer amount is required")]
        [Range(10000, 50000000, ErrorMessage = "Offer must be between 10,000 and 50,000,000")]
        [Display(Name = "Offer Amount (AED)")]
        public int OfferAmount { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Offer Type")]
        public string OfferType { get; set; } = "Purchase";

        [StringLength(500)]
        public string? Notes { get; set; }

        [StringLength(20)]
        public string Status { get; set; } = "Pending";

        public DateTime DateCreated { get; set; } = DateTime.Now;
    }
}
