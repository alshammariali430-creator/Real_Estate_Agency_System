using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RealEstateAgency.Models;

namespace RealEstateAgency.Models
{
    public class AppDbContext : IdentityDbContext<ApplicationUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // DbSet for each table
        public DbSet<Property> Properties { get; set; }
        public DbSet<Favorite> Favorites { get; set; }
        public DbSet<ViewingRequest> ViewingRequests { get; set; }
        public DbSet<Offer> Offers { get; set; }
        public DbSet<ApplicationUser> ApplicationUsers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ============================================================
            // Seed initial properties data
            // ============================================================
            modelBuilder.Entity<Property>().HasData(
                new Property
                {
                    PropertyID = 1,
                    Title = "Luxury Beachfront Villa",
                    Description = "Stunning 5-bedroom villa on Saadiyat Island with private beach access and infinity pool.",
                    Location = "Saadiyat Island",
                    City = "Abu Dhabi",
                    Price = 8500000,
                    Type = "Villa",
                    Bedrooms = 5,
                    Bathrooms = 6,
                    AreaSqft = 6500,
                    Status = "Available",
                    Listing = "Sale",
                    DateListed = new DateTime(2025, 1, 15),
                    ImageUrl = "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800"
                },
                new Property
                {
                    PropertyID = 2,
                    Title = "Modern Downtown Apartment",
                    Description = "Sleek 2-bedroom apartment in Downtown Dubai with stunning views of Burj Khalifa.",
                    Location = "Downtown Dubai",
                    City = "Dubai",
                    Price = 2200000,
                    Type = "Apartment",
                    Bedrooms = 2,
                    Bathrooms = 2,
                    AreaSqft = 1450,
                    Status = "Available",
                    Listing = "Sale",
                    DateListed = new DateTime(2025, 2, 3),
                    ImageUrl = "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800"
                },
                new Property
                {
                    PropertyID = 3,
                    Title = "Family Townhouse in Al Reef",
                    Description = "Spacious 3-bedroom townhouse in a family community with parks, pools, and schools.",
                    Location = "Al Reef",
                    City = "Abu Dhabi",
                    Price = 1750000,
                    Type = "Townhouse",
                    Bedrooms = 3,
                    Bathrooms = 4,
                    AreaSqft = 2100,
                    Status = "Available",
                    Listing = "Sale",
                    DateListed = new DateTime(2025, 2, 10),
                    ImageUrl = "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=800"
                },
                new Property
                {
                    PropertyID = 4,
                    Title = "Studio in MBZ City",
                    Description = "Affordable studio apartment for young professionals near ADNOC headquarters.",
                    Location = "Mohamed Bin Zayed City",
                    City = "Abu Dhabi",
                    Price = 65000,
                    Type = "Apartment",
                    Bedrooms = 0,
                    Bathrooms = 1,
                    AreaSqft = 550,
                    Status = "Available",
                    Listing = "Rent",
                    DateListed = new DateTime(2025, 3, 1),
                    ImageUrl = "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800"
                },
                new Property
                {
                    PropertyID = 5,
                    Title = "Penthouse on Palm Jumeirah",
                    Description = "Exclusive 4-bedroom penthouse with views of Arabian Gulf and Dubai skyline.",
                    Location = "Palm Jumeirah",
                    City = "Dubai",
                    Price = 15000000,
                    Type = "Penthouse",
                    Bedrooms = 4,
                    Bathrooms = 5,
                    AreaSqft = 5200,
                    Status = "Available",
                    Listing = "Sale",
                    DateListed = new DateTime(2025, 1, 20),
                    ImageUrl = "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800"
                },
                new Property
                {
                    PropertyID = 6,
                    Title = "Villa in Khalifa City",
                    Description = "Traditional 4-bedroom villa with maids room, drivers room, and large garden.",
                    Location = "Khalifa City",
                    City = "Abu Dhabi",
                    Price = 3200000,
                    Type = "Villa",
                    Bedrooms = 4,
                    Bathrooms = 5,
                    AreaSqft = 4500,
                    Status = "Available",
                    Listing = "Sale",
                    DateListed = new DateTime(2025, 2, 25),
                    ImageUrl = "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800"
                },
                new Property
                {
                    PropertyID = 7,
                    Title = "Marina View Apartment",
                    Description = "Beautiful 1-bedroom apartment in Dubai Marina with full marina views.",
                    Location = "Dubai Marina",
                    City = "Dubai",
                    Price = 95000,
                    Type = "Apartment",
                    Bedrooms = 1,
                    Bathrooms = 2,
                    AreaSqft = 850,
                    Status = "Available",
                    Listing = "Rent",
                    DateListed = new DateTime(2025, 3, 5),
                    ImageUrl = "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800"
                },
                new Property
                {
                    PropertyID = 8,
                    Title = "Townhouse in Yas Island",
                    Description = "Modern 3-bedroom townhouse near Yas Mall and Ferrari World.",
                    Location = "Yas Island",
                    City = "Abu Dhabi",
                    Price = 2400000,
                    Type = "Townhouse",
                    Bedrooms = 3,
                    Bathrooms = 4,
                    AreaSqft = 2800,
                    Status = "Available",
                    Listing = "Sale",
                    DateListed = new DateTime(2025, 2, 18),
                    ImageUrl = "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800"
                }
            );

            // ============================================================
            // Seeding roles and user data (Lab 12a pattern)
            // ============================================================
            var adminRoleId = "11111111-1111-1111-1111-111111111111";
            var memberRoleId = "22222222-2222-2222-2222-222222222222";

            // Create two sample roles in the roles table
            modelBuilder.Entity<IdentityRole>().HasData(
                new IdentityRole() { Id = adminRoleId, Name = "Admin", NormalizedName = "ADMIN" },
                new IdentityRole() { Id = memberRoleId, Name = "Member", NormalizedName = "MEMBER" }
            );

            // The hasher object hashes the user password before seeding it to the database
            var hasher = new PasswordHasher<ApplicationUser>();

            // Seed two users
            var userId1 = "33333333-3333-3333-3333-333333333333";
            var userId2 = "44444444-4444-4444-4444-444444444444";
            modelBuilder.Entity<ApplicationUser>().HasData(
                new ApplicationUser()
                {
                    Id = userId1,
                    UserName = "admin@realestate.com",
                    FirstName = "Admin",
                    LastName = "User",
                    Email = "admin@realestate.com",
                    NormalizedUserName = "ADMIN@REALESTATE.COM",
                    NormalizedEmail = "ADMIN@REALESTATE.COM",
                    PasswordHash = hasher.HashPassword(null!, "Pa$$w0rd")
                },
                new ApplicationUser()
                {
                    Id = userId2,
                    UserName = "member@realestate.com",
                    FirstName = "Member",
                    LastName = "User",
                    Email = "member@realestate.com",
                    NormalizedUserName = "MEMBER@REALESTATE.COM",
                    NormalizedEmail = "MEMBER@REALESTATE.COM",
                    PasswordHash = hasher.HashPassword(null!, "Pa$$w0rd")
                }
            );

            // Assign roles to users
            modelBuilder.Entity<IdentityUserRole<string>>().HasData(
                new IdentityUserRole<string>() { RoleId = adminRoleId, UserId = userId1 },
                new IdentityUserRole<string>() { RoleId = memberRoleId, UserId = userId2 }
            );
            // end of seeding
        }
    }
}
