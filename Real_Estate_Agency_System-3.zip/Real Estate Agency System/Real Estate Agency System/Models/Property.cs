using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RealEstateAgency.Models
{
    public class Property
    {
        [Key]
        public int PropertyID { get; set; }

        [Required(ErrorMessage = "Title is required")]
        [StringLength(150, MinimumLength = 5, ErrorMessage = "Title must be between 5 and 150 characters")]
        [Display(Name = "Property Title")]
        public string Title { get; set; } = string.Empty;

        [Required(ErrorMessage = "Description is required")]
        [StringLength(2000, MinimumLength = 20, ErrorMessage = "Description must be 20 to 2000 characters")]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Location is required")]
        [StringLength(100)]
        public string Location { get; set; } = string.Empty;

        [Required(ErrorMessage = "City is required")]
        [StringLength(50)]
        public string City { get; set; } = string.Empty;

        [Required]
        [Range(50000, 50000000, ErrorMessage = "Price must be between 50,000 and 50,000,000")]
        public int Price { get; set; }

        [Required(ErrorMessage = "Property type is required")]
        [Display(Name = "Property Type")]
        [StringLength(50)]
        public string Type { get; set; } = string.Empty;

        [Required]
        [Range(0, 20, ErrorMessage = "Bedrooms must be between 0 and 20")]
        public int Bedrooms { get; set; }

        [Required]
        [Range(1, 20, ErrorMessage = "Bathrooms must be between 1 and 20")]
        public int Bathrooms { get; set; }

        [Required]
        [Range(100, 100000, ErrorMessage = "Area must be between 100 and 100,000 sqft")]
        [Display(Name = "Area (sqft)")]
        public int AreaSqft { get; set; }

        [StringLength(20)]
        public string Status { get; set; } = "Available";

        [StringLength(20)]
        [Display(Name = "Sale or Rent")]
        public string Listing { get; set; } = "Sale";

        [Display(Name = "Date Listed")]
        [DataType(DataType.Date)]
        public DateTime DateListed { get; set; } = DateTime.Now;

        [StringLength(500)]
        [Display(Name = "Image URL")]
        public string? ImageUrl { get; set; }
    }
}
