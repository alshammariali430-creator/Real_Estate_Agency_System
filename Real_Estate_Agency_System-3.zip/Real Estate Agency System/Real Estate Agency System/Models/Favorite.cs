using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RealEstateAgency.Models
{
    public class Favorite
    {
        [Key]
        public int FavoriteID { get; set; }

        // Foreign key to Property
        [ForeignKey("Property")]
        public int PropertyID { get; set; }
        public Property? Property { get; set; }

        // Foreign key to AspNetUsers (set by controller from logged in user)
        public string AppUserID { get; set; } = string.Empty;

        public DateTime DateAdded { get; set; } = DateTime.Now;
    }
}
