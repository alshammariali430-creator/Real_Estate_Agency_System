using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RealEstateAgency.Models
{
    public class ViewingRequest
    {
        [Key]
        public int RequestID { get; set; }

        [ForeignKey("Property")]
        public int PropertyID { get; set; }
        public Property? Property { get; set; }

        // Set by controller from logged in user
        public string AppUserID { get; set; } = string.Empty;

        [Required(ErrorMessage = "Full name is required")]
        [StringLength(100, MinimumLength = 3)]
        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Phone number is required")]
        [Phone(ErrorMessage = "Please enter a valid phone number")]
        [Display(Name = "Phone Number")]
        [StringLength(20)]
        public string Phone { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Please enter a valid email")]
        [StringLength(100)]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Preferred date is required")]
        [DataType(DataType.Date)]
        [Display(Name = "Preferred Viewing Date")]
        public DateTime PreferredDate { get; set; } = DateTime.Now.AddDays(2);

        [Required(ErrorMessage = "Message is required")]
        [StringLength(500, MinimumLength = 10, ErrorMessage = "Message must be between 10 and 500 characters")]
        [DataType(DataType.MultilineText)]
        public string Message { get; set; } = string.Empty;

        [StringLength(20)]
        public string Status { get; set; } = "Pending";

        public DateTime DateSubmitted { get; set; } = DateTime.Now;
    }
}
